﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] matrizPrincipal = new double[2, 4];
            double[] TotalporMes = new double[2];
            double[] TotalporSem = new double[4];
            double TotalGeral = 0;

            listVendas.Items.Clear();

            for (int i = 0; i < matrizPrincipal.GetLength(0); i++)
            {
                for (int j = 0; j < matrizPrincipal.GetLength(1); j++)
                {

                    string input = Interaction.InputBox($"Total do Mês: {i}, Semana{j}: ");

                    if (input == "")
                    {
                        MessageBox.Show("Entrada cancelada. O programa será encerrado.");
                        return;
                    }

                    if (double.TryParse(input, out double valor) && valor >= 0)
                    {
                        matrizPrincipal[i, j] = valor;
                    }
                    else
                    {
                        MessageBox.Show("Valor inválido. Por favor, digite um número válido.");
                        j--;
                    }
                }
            }
            for (int i = 0; i < matrizPrincipal.GetLength(0); i++)
            {
                double somaSem = 0;

                for (int j = 0; j < matrizPrincipal.GetLength(1); j++)
                {
                    somaSem += matrizPrincipal[i, j];
                }

                TotalporSem[i] = somaSem;
                TotalporMes[i] = somaSem;
            }
            for (int i = 0; i < 4; i++)
            {
                TotalGeral += TotalporMes[i];
            }
            for (int i = 0; i < matrizPrincipal.GetLength(0); i++)
            {
                for (int j = 0; j < matrizPrincipal.GetLength(1); j++)
                {
                    listVendas.Items.Add($"Total do Mês:{i} Semana{j}: {{TotalporSem[i].ToString(\"C2\")}}\"); ");
                    listVendas.Items.Add($"Total do Mês:{i} Semana{j}: {{TotalporMes[i].ToString(\"C2\")}}\"); ");
                }
            }
        }
    }
}


